export const getBrandName = () => "Grow With Emon";


export const getBrandLogo = () => "/brand-logo.png";

export const getHomePageTitle = () => "Anamul Hasan Emon";
export const getHomePageDescription = () =>
  "Helping business owners drive real growth with data-driven marketing, clear ROI, and scalable strategies. Partner with Rifat to elevate your brand.";
export const getWhatsApp = () => "https://wa.me/8801737615995";
