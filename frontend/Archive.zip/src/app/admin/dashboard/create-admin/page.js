import React from "react";
import AdminCreate from "@/components/‎AdminCreate";

const Page = () => {
  return (
    <div>
      <AdminCreate />
    </div>
  );
};

export default Page;
