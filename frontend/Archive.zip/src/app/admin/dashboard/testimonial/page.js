import React from 'react';
import TestimonialUpload from "@/components/TestimonialUpload";

const Page = () => {
  return (
    <div>
      <TestimonialUpload/>
    </div>
  );
};

export default Page;