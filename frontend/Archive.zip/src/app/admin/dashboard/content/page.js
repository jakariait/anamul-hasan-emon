"use client"
import React from 'react';
import PageContentEditor from "@/components/PageContentEditor";

const Page = () => {
  return (
    <div>
      <PageContentEditor/>

    </div>
  );
};

export default Page;