"use client";

import React from 'react';
import BlogList from "@/components/BlogList";

const Page = () => {
  return (
    <div className={"xl:container xl:mx-auto"}>

      <BlogList />

    </div>
  );
};

export default Page;